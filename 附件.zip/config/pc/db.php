<?php
return [
    // 数据库配置 [模块]
    'mysqli' => [
        'host' => 'localhost',
        'username' => 'mycherry',
        'password' => 'zz123456@*',
        'dbname' => 'cherry',
        'port' => '3306',
        'drive' => 'mysqli',
        'tbPrefix' => 'cherry_'
    ]
];