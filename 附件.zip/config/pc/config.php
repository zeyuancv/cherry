<?php
return [
    // 数据库配置 [模块]
    'link' => 'www.baidu.com',
    'app_url' => 'www.google.com',
    'dbDrive' => 'mysqli',
];