<?php
return [
    // app 内应用注册，如app新增模块，请在这里加上
    'registerApp' => ['pc' => ['domain_prefix' => ['www', 'bbs']],
        'mobile' => ['domain_prefix' => ['m', 'mobile'],
        ],
        'app' => ['domain_prefix' => ['myapp', 'app'],]],
        'defaultapp' => 'pc'
    ];