<?php
namespace App\pc\users\model;

class UsersModel extends \Zeyuan\Cherry\mvc\Model{
	
	public function getUsers(){
		$users = $this->_db->get('users'); 
		print_r($users);
	}
}