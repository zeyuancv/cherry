<?php
namespace App\pc\users\controller;
use Zeyuan\Cherry\mvc;

class UsersController extends \Zeyuan\Cherry\mvc\Controller{
	
	public function index(){
		$model = new \App\pc\users\model\UsersModel;
		$model->getUsers();
		
		$this->assign('ss',111);
		$this->render('index.php');
		echo 222;
	}
	
}